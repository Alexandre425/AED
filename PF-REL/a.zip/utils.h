#pragma once

#include <stdio.h>
#include <stdlib.h>

void *calloc_check(int n_memb, size_t s_memb);
void *malloc_check(int n_memb, size_t s_memb);