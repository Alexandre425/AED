#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void arguments_check(int argc, char *argv[]);
